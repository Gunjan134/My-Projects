import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SERVER_API_URL } from '../constants/app.constants';
import { Employee } from '../models/employee.model';

@Injectable({ providedIn: 'root' })
export class EmployeeService {
  public resourceUrl = SERVER_API_URL + 'api/v1/employee';

  constructor(protected http: HttpClient) {}

  addEmployee(employee: Employee): Observable<any> {
    return this.http.post(`${this.resourceUrl}/create`, employee);
  }

  deleteEmployee(id: number): Observable<any> {
    return this.http.delete(`${this.resourceUrl}/delete/${id}`);
  }

  updateEmployee(employee: Employee): Observable<any> {
    return this.http.put(`${this.resourceUrl}/update/${employee.id}`, employee);
  }

  getAllEmployees(): Observable<any> {
    return this.http.get(`${this.resourceUrl}/getAll`);
  }

  getEmployeeById(id: number): Observable<any> {
    return this.http.get(`${this.resourceUrl}/get/${id}`);
  }
}
