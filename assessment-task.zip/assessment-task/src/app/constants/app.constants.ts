export const SERVER_API_URL = 'http://www.appgrowthcompany.com:5069/';
