import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Employee } from '../../models/employee.model';
import { EmployeeService } from '../../services/employee.service';
import { AddItemComponent } from '../add-item/add-item.component';
import { ItemComponent } from '../item/item.component';

@Component({
  selector: 'app-items-list',
  templateUrl: './items-list.component.html',
  styleUrls: ['./items-list.component.scss'],
})
export class ItemsListComponent implements OnInit, AfterViewInit {
  displayedColumns: string[] = [
    'id',
    'employee_name',
    'employee_salary',
    'employee_age',
    'details',
    'edit',
    'delete',
  ];
  employees: Array<Employee>;
  employeesDataSource = new MatTableDataSource<Employee>([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort, {}) sort: MatSort;
  filterValue = '';

  constructor(
    private employeeService: EmployeeService,
    public dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    this.employeeService.getAllEmployees().subscribe((res) => {
      this.employees = res.allEmployees;
      this.employeesDataSource.data = this.employees;
    });
  }

  ngAfterViewInit(): void {
    this.employeesDataSource.paginator = this.paginator;
    this.employeesDataSource.sort = this.sort;
  }

  viewDetails(id: number): void {
    this.employeeService.getEmployeeById(id).subscribe((res) => {
      this.dialog.open(ItemComponent, {
        width: '250px',
        data: res.data,
      });
    });
  }

  filterEmployee = (value: string) => {
    this.employeesDataSource.filter = value.trim().toLowerCase();
    this.loadData();
  };

  clearSearch(): void {
    this.filterValue = '';
    this.filterEmployee(this.filterValue);
  }

  addEmployee(): void {
    const dialogRef = this.dialog.open(AddItemComponent, {
      width: '350px',
    });
    dialogRef.afterClosed().subscribe((result) => {
      this.employeesDataSource.data.push(result);
      this.employeesDataSource.paginator = this.paginator;
      this.employeesDataSource.sort = this.sort;
    });
  }

  delete(id: number): void {
    this.employeeService.deleteEmployee(id).subscribe();
    const deleteIndex = this.employeesDataSource.data.findIndex(
      (el) => el.id === id
    );
    this.employeesDataSource.data.splice(deleteIndex, 1);
    this.employeesDataSource.paginator = this.paginator;
    this.employeesDataSource.sort = this.sort;
  }

  edit(employee: Employee): void {
    this.dialog.open(AddItemComponent, {
      width: '350px',
      data: {
        employeeModel: employee,
        editMode: true,
      },
    });
  }
}
