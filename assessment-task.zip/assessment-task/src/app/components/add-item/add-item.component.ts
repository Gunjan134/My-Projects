import { Component, Inject, Input } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Employee } from '../../models/employee.model';
import { EmployeeService } from '../../services/employee.service';

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.scss'],
})
export class AddItemComponent {
  @Input() employeeModel: Employee = {};
  @Input() editMode: boolean;

  constructor(
    public dialogRef: MatDialogRef<AddItemComponent>,
    private employeeService: EmployeeService,
    @Inject(MAT_DIALOG_DATA)
    public data: {
      employeeModel: Employee;
      editMode: boolean;
    }
  ) {}

  addEmployee(): void {
    this.employeeService.addEmployee(this.employeeModel).subscribe();
    this.closeDialog();
  }

  updateEmployee(): void {
    this.employeeService.updateEmployee(this.data?.employeeModel).subscribe();
    this.closeDialog();
  }

  closeDialog(): void {
    this.dialogRef.close(this.employeeModel);
  }
}
